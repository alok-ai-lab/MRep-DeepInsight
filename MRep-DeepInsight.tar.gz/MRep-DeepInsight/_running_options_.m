Parm.Assignment='yes';
Parm.Blur='no';
Parm.Dist='hamming';
Parm.MaxEpochs=10;%10;
Parm.FeatureMap=1;

Parm.trainingPlot='none';
Parm.MaxObj=15; 
Parm.Norm = 1;

Parm.MaxEpochs=100;
Parm.L2Regularization=L2Reg;
Parm.Momentum=Momentum;
Parm.InitialLearnRate=InitLR;
Parm.MaxObj=1;
Parm.trainingPlot='training-progress';
Parm.filterSize=3;
Parm.filterSize2=4;
Parm.initialNumFilters=3;

% Transfer Learning
unix(['cp model.mat Models/Run32/Stage1/']);
Parm.TransLearn=1;
curr_dir=pwd;
FIGS_path = [curr_dir,'/FIGS/'];
Models_path = [curr_dir,'/Models/'];
Data_path = [curr_dir,'/Data/'];
Parm.PATH{1} =  FIGS_path; %'~/DeepInsight3D/FIGS/'; %Store figures in this folder
Parm.PATH{2} = Models_path; %'~/DeepInsight3D_pkg/Models/'; % Store model in this folder
Parm.PATH{3} = Data_path; % store your data here

if Parm.TransLearn==1
    Parm.TLdir = 'Run32'; % Define as per the path of your stored model.
    Parm.TLfile = [Models_path,Parm.TLdir,'/Stage1/model.mat'];
    cd(Parm.TLfile(1:end-9)); 
    Mod = load(Parm.TLfile);
    ModF = load(Mod.fileName);
    cd(curr_dir);
    %Parm.DAGnet = ModF.trainedNet;
    Parm.net = ModF.trainedNet;
end
% ######
% merging tsne + umap
Len=size(prob.test,1);
Duplicate = 4;
Len=Len/Duplicate;

% Equal weights
y=zeros(Len,size(prob.test,2));
for j=1:Duplicate
    y=prob.test((j-1)*Len+1:j*Len,:)+y;
end
y=y/Duplicate;
clear c
for j=1:Len
    [r,c(j)]=max(y(j,:));
end
c=c';
Integrated_Acc = mean(double(prob.YTest(1:Len))==c)

%weighted with log reg
Xtr=[];
LenV = size(prob.val,1)/Duplicate;
for j=1:Duplicate
    Xtr=[Xtr,prob.val((j-1)*LenV+1:j*LenV,:)];
    Xts=[Xts,prob.test((j-1)*Len+1:j*Len,:)];
end
Ytr=prob.YValidation(1:LenV);
Yts=prob.YTest(1:Len);

current_dir=pwd;
cd ~/MatWorks/Unsup/liblinear-2.11/matlab/
model=train(double(Ytr),sparse(double(Xtr)),['-s 0','liblinear_options',]);
[yhat,acc,Y]=predict(double(Yts),sparse(double(Xts)),model,['-b 1']);
C=confusionmat(Yts,categorical(round(yhat)));
cd(current_dir);
Integrated_Acc_weighted = acc(1)
% ########
